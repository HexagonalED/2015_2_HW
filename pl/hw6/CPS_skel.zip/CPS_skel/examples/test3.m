(* Public testcase 3 : pair *)

((fn x => (x, 3)) 2).2

(* Output : 3 *)

let a : t * t * t -> t 

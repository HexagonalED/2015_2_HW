exception Error of string;;

